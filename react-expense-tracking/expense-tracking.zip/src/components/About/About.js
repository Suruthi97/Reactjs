import './About.css';
import expense from '../../assests/expense.jpg';

const About=()=>{
   return(<div>
       <img src={expense} style={{width:"900px",height:"300px"}}  />
   </div>)
}

export default About;
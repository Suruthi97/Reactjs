
function Reports() {
    return (<div className="right-part2">
        <p className="nav-select-content"><h4 className="dashboarditem">Reports</h4>  </p>
        <div className="box-content" >
        </div>
    </div>);
}
export default Reports;
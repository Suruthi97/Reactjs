
function Projects() {
    return (<div className="right-part2">
        <p className="nav-select-content ">
            <h4 className="dashboarditem">Projects</h4>  </p>
        <div className="box-content" >
        </div>
    </div>);
}
export default Projects;
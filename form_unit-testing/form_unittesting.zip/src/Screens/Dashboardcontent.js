function Dashboardcontent() {
    return (
        <div className="right-part2" data-testid="dashboard-component">
            <h4 className="nav-select-content dashboarditem">Dashboard</h4>
            <div className="box-content" >
            </div>
        
    </div>);
}
export default Dashboardcontent;


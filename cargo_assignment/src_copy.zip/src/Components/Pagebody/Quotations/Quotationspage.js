import Filter from '../../TableData/Filter';
import Data4 from './Data4';
import Search from '../../TableData/Search';
import Select from '../../TableData/Select';
import Card from '../../TableData/Card';
import Button from '@mui/material/Button';
function Quotationspage() {
    return (<div className="div">
        <div className="table1">
            <table>
                <tbody>
                    <tr>
                        <td>
                            <Filter />
                        </td>
                        <td>
                            <Search name="Search Quotation" className="search1"/>
                            {/* <Button className="button2" variant="contained" >
                                New Quote
                            </Button> */}
                        </td>
                        <td>
                            <Card name="Quotation" />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <Data4 />
                        </td>
                        <td>
                            <Select class="data5" />
                        </td>
                        <td>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>);
}
export default Quotationspage;
import Header from '../Components/Header/Header';
import Notification from '../Components/Header/Notification';
function Reports() {
    return (
        <div>
            <Header/>
            <Notification name="Reports"/>
        </div>
    );
}

export default Reports;
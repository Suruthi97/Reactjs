import Data1 from './Data1';
import Data2 from './Data2';
import Data3 from './Data3';
import Data4 from './Data4';
function Shipmentpage() {
    return (<div>
        <div className="table1">
            <table>
                <tbody>
                    <tr>
                        <td>
                            <Data1 />
                        </td>
                        <td className='tdata'>
                            <Data3/>
                        </td>
                        <td className='tdata'>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <Data2 />
                        </td>
                        <td className='tdata'>
                            <Data4/>
                        </td>
                        <td className='tdata'>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>);
}
export default Shipmentpage;
import * as React from 'react';
import Paper from '@mui/material/Paper';
import InputBase from '@mui/material/InputBase';
import IconButton from '@mui/material/IconButton';
import SearchIcon from '@mui/icons-material/Search';
function Data2() {
    return (<div>
        <Paper className="data3">
            <IconButton type="submit" aria-label="search">
                <SearchIcon />
            </IconButton>
            <InputBase placeholder="Search Shipments" />
        </Paper>
    </div>);
}
export default Data2;
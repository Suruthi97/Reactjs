function Data4() {
    return (<div className="data4">
                        <div>
                            <span className="span">Items per page:&nbsp;&nbsp;&nbsp;
                                <select name="numbers" id="numbers">
                                    <option value="25">25</option>
                                    <option value="50">50</option>
                                    <option value="75">75</option>
                                    <option value="100">100</option>
                                </select>
                            </span>&nbsp;&nbsp;&nbsp;
                            <span>0 of 0</span>&nbsp;&nbsp;&nbsp;
                            <span><i className="fa-solid fa-angle-left"></i></span>
                            <span><i className="fa-solid fa-angle-right"></i></span>
                        </div>
    </div>);
}
export default Data4;
import './App.scss';
import Dashboard from './Screens/Dashboard';
import Shipments from './Screens/Shipments';
import Invoices from './Screens/Invoices';
import Quotations from './Screens/Quotations';
import Shipper from './Screens/Shipper';
import Reports from './Screens/Reports';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
function App() {
  return (<div>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Dashboard />} />
          <Route path='/shipments' element={<Shipments />} />
          <Route path='/invoices' element={<Invoices />} />
          <Route path='/quotations' element={<Quotations />} />
          <Route path='/shipper' element={<Shipper />} />
          <Route path='/reports' element={<Reports />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}
export default App;
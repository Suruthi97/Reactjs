import Header from '../Components/Header/Header';
import Notification from '../Components/Header/Notification';
function Quotations() {
    return (
        <div>
            <Header/>
            <Notification name="Quotation"/>
        </div>
    );
}

export default Quotations;
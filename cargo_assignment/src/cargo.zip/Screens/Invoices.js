import Header from '../Components/Header/Header';
import Notification from '../Components/Header/Notification';
function Invoices() {
    return (
        <div>
            <Header/>
            <Notification name="Invoice"/>
        </div>
    );
}

export default Invoices;
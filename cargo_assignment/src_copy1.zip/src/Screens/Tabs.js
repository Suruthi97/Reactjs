import * as React from "react";
import CssBaseline from "@mui/material/CssBaseline";
import Header from "../Components/Header/Header";

function Tabs() {
    return (
      <div className="ds_page">
      <React.Fragment>
        <CssBaseline />
        <Header/>
        </React.Fragment>
    </div>
    );
  }
  export default Tabs;
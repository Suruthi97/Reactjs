export const formInitialState = {
    loginForm:
    {
        email: '',
        password: ''
    },
    registerForm:
    {
        firstName:'',
        lastName:'',
        email: '',
        password: ''
    }
}